<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\SERVER\htdocs\messenger-app\resources\views/welcome.blade.php ENDPATH**/ ?>