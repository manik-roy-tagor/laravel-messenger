  

<?php $__env->startSection('content'); ?>
<div class="container-fluid h-100">
    <div class="row h-100">
        <!-- Left Sidebar: Chat List -->
        <div class="col-md-4 col-lg-3 bg-white shadow-sm p-3 overflow-auto" style="height: 100vh;">
            <h2 class="h4 mb-4 text-center text-primary">Chat List</h2>
            <ul class="list-group">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('messenger.index', ['userId' => $user->id])); ?>">
                    <li class="list-group-item list-group-item-action d-flex align-items-center p-3 bg-light">
                        <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode($user->name)); ?>&background=4CAF50&color=fff" alt="<?php echo e($user->name); ?>" class="rounded-circle me-3" width="40" height="40">
                        <div>
                            <p class="mb-0 font-weight-bold"><?php echo e($user->name); ?></p>
                            <p class="mb-0 text-muted small">Last message...  </p>
                        </div>
                    </li>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- আরও চ্যাট আইটেম যোগ করুন -->
            </ul>
        </div>

        <!-- Right Main: Chat Window -->
        <div class="col-md-8 col-lg-9 d-flex flex-column">
            <div class="bg-white p-3 shadow-sm d-flex justify-content-between align-items-center">
                <h2 class="h5 mb-0">Chatting with <?php echo e($selectedUserName ?? 'Unknown User'); ?></h2>  
            </div>

            <div class="flex-grow-1 p-3 overflow-auto bg-light" style="height: calc(100vh - 100px);">
                <!-- Message List -->
                <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>  
                <div class="d-flex align-items-start mb-2 <?php echo e($message->user_id == auth()->id() ? 'justify-content-end' : 'justify-content-start'); ?>">
                    <div class="d-flex flex-column">
                        <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode($message->user->name ?? 'User')); ?>&background=4CAF50&color=fff" alt="<?php echo e($message->user->name ?? 'User'); ?>" class="rounded-circle <?php echo e($message->user_id == auth()->id() ? 'order-last' : ''); ?> me-2" width="30" height="30">
                        <div class="bg-<?php echo e($message->user_id == auth()->id() ? 'primary' : 'success'); ?> bg-opacity-10 p-2 rounded-pill">
                            <p class="mb-0 text-dark small"><?php echo e($message->content ?? 'No content'); ?></p>  
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-muted text-center">No messages yet.</p>
                <?php endif; ?>
                <!-- আরও মেসেজ যোগ করুন -->
            </div>

            <!-- Message Input -->
            <div class="p-3 bg-white shadow-sm">
                <form action="<?php echo e(route('messenger.send', ['userId' => $userId])); ?>" method="POST">
                    <?php echo csrf_field(); ?>  
                    <input type="hidden" name="receiver_id" value="<?php echo e($userId); ?>">  
                    <div class="input-group">
                        <input type="text" name="content" class="form-control" placeholder="Type a message..." aria-label="Message" required>
                        <input type="hidden" name="type" value="text">  
                        <button class="btn btn-primary" type="submit">Send</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\SERVER\htdocs\messenger-app\resources\views/messenger/chat.blade.php ENDPATH**/ ?>